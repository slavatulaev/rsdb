#!/usr/bin/env python
import random
import string
import ftplib
import zipfile
import os

def genRandomString(length):  # генерирует и возвращает строку случайных символов заданой длины в нижнем регистре
    rS = ''.join(random.choices(string.ascii_lowercase + string.digits, k=length))
    return rS

def genRandomStringUp(length):  # генерирует и возвращает строку случайных символов заданой длины в верхнем регистре
    rS = ''.join(random.choices(string.ascii_uppercase + string.digits, k=length))
    return rS

def genRandomStringMix(length):  # генерирует и возвращает строку случайных символов заданой длины
    rS = ''.join(random.choices(string.ascii_uppercase + string.ascii_lowercase + string.digits, k=length))
    return rS

def ftpUploadFile(ftp, ftpPath, ftpLogin, ftpPassword, filePath): # загрузка файла на ftp
    ftpFilePath = ''
    fileName = filePath.split('/')[-1]
    i = 0
    while True:
        try:
            print('connecting ftp://' + ftp + ' - try ' + str(i))
            ftpObj = ftplib.FTP(ftp, ftpLogin, ftpPassword, timeout = 10 )
            print(ftpObj)
            print("ftp connected succesfully")
            break
        except:
            i += 1
            if i > 10 : 
                return ''
    print("changing directory...")
    ftpObj.cwd(ftpPath)
    print("directory changed succesfully")
    i = 0
    while True:
        try:
            print("opening file " + filePath)
            f = open(filePath, 'rb')
            print("sending file to ftp...")
            ftpObj.storbinary("STOR "+ filePath, f)
            print("closing ftp connection ...")
            ftpObj.quit()
            f.close()
            ftpFilePath = fileName
            break
        except:
            print("faled to upload %s to ftp" % filePath)
            i += 1
            f.close()
            if i > 10 : 
                return ''
            print("this is try nomber %s, will try again now..." % str(i))
    return ftpFilePath                                            # возвращает путь к файлу на ftp

def zipFiles(filesList = (), nameLen = 32):  # создает во временном каталоге архив с рандомным названием из nameLen-х символов
    zipFilePath = 'tmp/' + genRandomString(nameLen) + '.zip'
    try:
        os.mkdir('tmp')
    except:
        pass
    try: 
        zipFile = zipfile.ZipFile(zipFilePath, 'w', zipfile.ZIP_DEFLATED)
        for f in filesList:
            zipFile.write(f)
        zipFile.close()
    except:
        return ''
    return zipFilePath

# ftpUploadFile('files.000webhost.com','public_html','cryptocashback','qaz1XsW2','workList.csv')